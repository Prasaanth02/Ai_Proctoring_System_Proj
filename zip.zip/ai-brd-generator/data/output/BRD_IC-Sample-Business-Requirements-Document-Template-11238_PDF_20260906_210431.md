# Business Requirements Document".

   - The output must follow the exact structure provided (sections 1-14).

2.  **Analyze the Source Text:**
   - The source text is a template with sample text. It includes sections like VERSION HISTORY, TABLE OF CONTENTS, and then sections 1-16 with sample text.
   - Crucially, the sample text is clearly marked as "SAMPLE TEXT" and is not actual project data. It's generic placeholder content.
   - The actual "requirements" or "business data" within the source are just examples/samples, not real project specifics.
   - I need to extract information ONLY from the provided source text. But the source text is a template with sample text. There's no real project data.
   - According to the rules: "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"
   - Since the source is a template with sample text, and I'm told to extract ONLY from the source, but the source doesn't contain real project requirements, I should treat each section as "Not specified in the provided requirements." unless there's actual non-sample content.
   - Let me scan for any content that isn't explicitly "SAMPLE TEXT" marker.
   - The source has: VERSION HISTORY (empty/placeholder), TABLE OF CONTENTS, then sections 1-16 with "SAMPLE TEXT" throughout.
   - There's no actual project-specific information. Everything is sample placeholder text.
   - The instructions say: "Extract information ONLY from the provided source text." and "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"
   - Since the source is entirely sample/template text, I should treat all sections as not having real information, and output "Not specified in the provided requirements." for each section that doesn't have actual data.
   - But wait: The source does contain some text that isn't labeled "SAMPLE TEXT" in every paragraph, but overall it's a template. Let me check carefully.
   - Actually, reading the source: It's a "SAMPLE BUSINESS REQUIREMENTS DOCUMENT TEMPLATE". The content within is marked as "SAMPLE TEXT". The user probably wants me to generate a BRD based on this template, but the rules say extract ONLY from the provided source text, and if not present, write "Not specified...".
   - This is a meta situation. The source is a template with sample text. I cannot invent requirements. I must output "Not specified..." for sections where the sample text is just generic placeholder.
   - However, maybe I should treat the sample text as the "source text" and extract from it? But the sample text is clearly placeholders like "Etc.", "SAMPLE TEXT: ...", etc. It doesn't contain real requirements.
   - The rules say: "Do NOT invent, assume, or hallucinate any business requirements." and "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"
   - I think the intent is: The source text provided is the entirety of the input. I should look at it, and if a section has actual content (even if sample), I should extract it, but since it's all sample, I should output "Not specified..." for each.
   - But let's look at the structure: The user provided a source document. I need to generate a BRD in the specified format. The source text is a template. I should probably treat the source as having no real project data, so all sections get "Not specified...".
   - However, maybe I can use the sample text as the content? But the rules explicitly say not to invent/assume/hallucinate. Sample text is essentially invented placeholders. Using them would be hallucinating real requirements.
   - I'll go with: For each section, since the source contains only template/sample text and no actual project-specific requirements, I'll output "Not specified in the provided requirements." for sections that need content, but I need to follow the exact structure.
   - Wait, the structure has sections 1-14. Some sections might have text in the source that isn't explicitly "SAMPLE TEXT" but is part of the template. Let me re-read the source carefully.
   - The source starts with "SAMPLE BUSINESS REQUIREMENTS DOCUMENT TEMPLATE", then "VERSION HISTORY", then "TABLE OF CONTENTS", then sections 1-16 with "SAMPLE TEXT" throughout.
   - There's no actual project data. Everything is "SAMPLE TEXT" or placeholders.
   - According to the strict rules: "Extract information ONLY from the provided source text." The source text is the template. If I extract the "SAMPLE TEXT" content, that would be extracting, but it's not real requirements. The rules say "Do NOT invent, assume, or hallucinate any business requirements." Using sample text as real requirements would violate this.
   - The rules also say: "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'" Since the source doesn't contain actual project information, all sections should have that phrase.
   - But maybe some sections have non-sample text? Let me check: The VERSION HISTORY table has no filled data. TABLE OF CONTENTS is just listings. Sections 1-16 all have "SAMPLE TEXT" markers. There's no actual business data.
   - I'll output the BRD structure with "Not specified in the provided requirements." for each section that requires content, as per the instruction.
   - However, I need to be careful: The output must begin with exactly "# Business Requirements Document". Then the sections.
   - Let me structure it. For each section, I'll write the section header, and then the content. If the section is "Not specified...", I'll put that phrase.
   - But the instruction says: "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'" It doesn't say to put it as the only text in the section, but likely that's the intent.
   - I'll assume that for each section, since no real information is present, I'll write "Not specified in the provided requirements." as the content for that section.
   - Wait, maybe I should only put that phrase for sections where info is missing, but the source has some text. But the text is all sample. I think the safest is to treat the entire source as "not providing actual requirements", so all sections get that phrase.
   - Let me re-read the user prompt: "Generate the BRD using this exact structure:" and lists sections 1-14. Then: "Rules: Extract information ONLY from the provided source text. Do NOT invent, assume, or hallucinate any business requirements. If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"
   - I'll generate the BRD with headers, and for each section, since the source doesn't contain actual project requirements (it's a template with sample text), I'll put "Not specified in the provided requirements."
   - But maybe the "sample text" is considered part of the source, and I should extract from it? No, because it explicitly says "Do NOT invent, assume, or hallucinate". Sample text is placeholders, not real requirements.
   - I'll proceed with "Not specified in the provided requirements." for each section.

   Let me draft the output:

   # Business Requirements Document

   ## 1. Project Title
   Not specified in the provided requirements.

   ## 2. Executive Summary
   Not specified in the provided requirements.

   ... and so on for all sections.

   But wait, maybe I should check if any section has actual non-sample text. Looking at the source: The "NOTE TO USER: Overwrite the sample text included in this template to complete your project’s business requirements document." That's instruction, not requirement. The rest is all "SAMPLE TEXT" or empty.
   I'll output exactly as required.

   One thing: The structure says "## 1. Project Title" etc. I'll follow that.
   Also, the output must be ONLY the final BRD in markdown, no thinking, no notes before or after. Begin with exactly "# Business Requirements Document".

   I'll generate it now. I'll make sure each section header matches exactly the provided structure, and the content is "Not specified in the provided requirements." for each.

   Let me list all sections from the structure:
   # Business Requirements Document
   
   ## 1. Project Title
   
   ## 2. Executive Summary
   
   ## 3. Business Background / Problem Statement
   
   ## 4. Business Objectives
   
   ## 5. Scope
   
   ### In Scope
   
   ### Out of Scope
   
   ## 6. Stakeholders
   
   ## 7. Functional Requirements
   
   (Label each as FR-01, FR-02, etc.)
   
   ## 8. Non-Functional Requirements
   
   (Label each as NFR-01, NFR-02, etc.)
   
   ## 9. Business Rules
   
   ## 10. Assumptions
   
   ## 11. Constraints
   
   ## 12. Dependencies
   
   ## 13. Risks
   
   ## 14. Success Criteria

   For sections 7 and 8, they have sub-labels. I need to handle them. Since no requirements are specified, I'll still list the labels but with "Not specified..." or maybe just the phrase. The instruction says: "(Label each as FR-01, FR-02, etc.)" and "(Label each as NFR-01, NFR-02, etc.)". I'll include the labels but put "Not specified in the provided requirements." under each, or just state the phrase. To be safe, I'll put the section header, and then "Not specified in the provided requirements." For FR and NFR, I'll list FR-01, FR-02, etc., with the phrase.

   Actually, the rule: "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'" I'll interpret that as the content for each section being that exact phrase. For FR and NFR, I'll output the labels with the phrase, or just the phrase under the section. I'll do:

   ## 7. Functional Requirements
   FR-01: Not specified in the provided requirements.
   FR-02: Not specified in the provided requirements.
   ... but how many? I don't know. Maybe I should just put "Not specified in the provided requirements." under the section, and not list individual FRs if not specified. But the structure says "(Label each as FR-01, FR-02, etc.)". I'll include a couple of labels with the phrase, or just the section phrase. To avoid hallucinating the number, I'll just put "Not specified in the provided requirements." under the section, and maybe mention that requirements are not specified. But the rule says write exactly that phrase if info not present. I'll put the phrase as the content for each section.

   Let me think differently: Perhaps the user expects me to use the sample text from the source as the content, since it's the only text provided. But the rules explicitly forbid hallucinating/inventing. The sample text is clearly placeholders ("Etc.", "SAMPLE TEXT: ..."). Using them would be violating the rules. The safest and correct approach per the rules is to output "Not specified in the provided requirements." for any section that doesn't have actual, non-sample project data.

   I'll proceed with that.

   Output structure:
   # Business Requirements Document
   ## 1. Project Title
   Not specified in the provided requirements.
   ## 2. Executive Summary
   Not specified in the provided requirements.
   ... etc.

   I'll make sure there are no extra texts, no reasoning, just the markdown BRD.

   Let me generate it carefully. I'll count the sections: 1 to 14 as per the user's structure list. The user's structure says:
   ## 1. Project Title
   ## 2. Executive Summary
   ## 3. Business Background / Problem Statement
   ## 4. Business Objectives
   ## 5. Scope
   ### In Scope
   ### Out of Scope
   ## 6. Stakeholders
   ## 7. Functional Requirements
   (Label each as FR-01, FR-02, etc.)
   ## 8. Non-Functional Requirements
   (Label each as NFR-01, NFR-02, etc.)
   ## 9. Business Rules
   ## 10. Assumptions
   ## 11. Constraints
   ## 12. Dependencies
   ## 13. Risks
   ## 14. Success Criteria

   I'll output exactly that. For each section, the content will be "Not specified in the provided requirements." Except for 7 and 8, I'll list FR-01, FR-02, etc., and NFR-01, NFR-02, etc., but since no requirements are given, I'll just put