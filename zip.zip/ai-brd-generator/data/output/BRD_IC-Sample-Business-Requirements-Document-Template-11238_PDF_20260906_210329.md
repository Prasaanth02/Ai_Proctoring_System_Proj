# Business Requirements Document`
   - Output must use the exact structure provided in the prompt.

2.  **Identify the Source Text:**
   - The source text is the entire "SAMPLE BUSINESS REQUIREMENTS DOCUMENT TEMPLATE" provided by the user.
   - It contains sample text placeholders like "SAMPLE TEXT:", "NOTE TO USER:", version history, company info placeholders, table of contents, and detailed section samples.
   - Crucially, it does NOT contain actual project-specific data for a real project. It's a template with sample fill-ins.

3.  **Determine What to Do:**
   - I need to generate a BRD structure as requested.
   - I must populate each section using ONLY the source text.
   - If a section or sub-item isn't explicitly provided with real content in the source, I must write "Not specified in the provided requirements."
   - I must avoid hallucinating or adding real business content.
   - The source text is a template with sample descriptions, but they are clearly marked as "SAMPLE TEXT" and are not actual project requirements. They are examples of what could go in those sections.

4.  **Map Source Text to Target Structure:**
   Let's go section by section as per the prompt's required structure:

   `# Business Requirements Document`

   ## 1. Project Title
   - Source has: "PROJECT NAME" and "COMPANY NAME" placeholders, but no specific project title given. The source has "SAMPLE BUSINESS REQUIREMENTS DOCUMENT TEMPLATE" as a header, but no actual project title. I should treat this as not specified, or maybe use the template name? Rules say extract ONLY from source text. The source has "PROJECT NAME" line but no value filled in. I'll write "Not specified in the provided requirements." because there's no actual project title extracted from source content.

   Wait, let's re-read carefully. The source has:
   ```
   PROJECT NAME
 
   COMPANY NAME 
   Street Address 
   City, State and Zip 
   
   webaddress.com 
   
   VERSION 0.0.0 
   
   00/00/0000 
   ```
   And "SAMPLE BUSINESS REQUIREMENTS DOCUMENT TEMPLATE" everywhere. There's no actual project title. So "Not specified in the provided requirements."

   ## 2. Executive Summary
   - Source has "1. EXECUTIVE SUMMARY SNAPSHOT" section with sample text. The sample text is about EV charging provider, tripling stations, etc. But it's marked "SAMPLE TEXT:" and is not actual project data. The rule: "Extract information ONLY from the provided source text." and "Do NOT invent, assume, or hallucinate any business requirements." The sample text is part of the source, but it's generic template sample. I need to decide: do I include the sample text as the executive summary? The rule says extract ONLY from the provided source text. The source text includes the sample text. But the sample text is clearly labeled "SAMPLE TEXT:" and is not "requirements" per se, it's template guidance. However, the user wants me to generate a BRD from the provided source text. I think I should treat the entire source as the text to extract from. But the source is a template with placeholders and sample texts. The instructions say: "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'" So I need to check if each section's information is "present in the source". The source has sections with "SAMPLE TEXT:" entries. Are those considered "present"? I think the intent is that the source text is the template, and I should use the content therein, but only the actual content, not the sample labels. However, the rule "Do NOT invent, assume, or hallucinate any business requirements" is key. The sample texts are not real requirements; they are examples. If I include them, I might be hallucinating real project requirements. But the user says "Generate the BRD using this exact structure" and "Extract information ONLY from the provided source text." This is tricky.

   Let's read the very first instruction: "Your task is to generate a professional, structured Business Requirements Document (BRD) from the provided source text." and "Extract information ONLY from the provided source text. Do NOT invent, assume, or hallucinate any business requirements. If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"

   So I need to go through the source text, and for each of the 14 sections in the target structure, determine if there's actual information for that section. The source text is a template with sample texts. I should treat the "SAMPLE TEXT:" entries as not being the actual project requirements, but as part of the template description. Since the source doesn't contain a real project's BRD, only a generic template, most sections won't have actual content beyond the template descriptions. But I must extract ONLY what's present. I think the safest is: for each section, if the source contains text that could fill it, but it's generic/sample, I should still consider whether it's "information" or "template guidance". The rule says "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'" This implies that if the source has something, I should use it, but only what's there. However, the source has "SAMPLE TEXT:" which is clearly not real project info. I need to interpret "provided source text" as the entire block the user pasted. I'll go through each target section and see if the source has a matching section with content.

   Let's map the source's sections to the target's required structure:

   Source has:
   - VERSION HISTORY, PROJECT NAME, COMPANY NAME, etc. (header info)
   - TABLE OF CONTENTS (with sections 1-16)
   - 1. EXECUTIVE SUMMARY SNAPSHOT (with sample text)
   - 2. PROJECT DESCRIPTION (with sample text)
   - 3. PROJECT SCOPE (with In Scope and Out of Scope, with sample text)
   - 4. BUSINESS DRIVERS (with sample text)
   - 5. CURRENT PROCESS (with sample text)
   - 6. PROPOSED PROCESS (with sample text)
   - 7. FUNCTIONAL REQUIREMENTS (with PRIORITY table and REQUIREMENTS CATEGORIES, with sample text)
   - 8. NON-FUNCTIONAL REQUIREMENTS (with ID/Requirement, with sample text)
   - 9. FINANCIAL STATEMENTS (with sample text)
   - 10. COST AND BENEFIT (with sample text)
   - 11. RESOURCES (with sample text)
   - 12. SCHEDULE, TIMELINE, AND DEADLINES (with sample text)
   - 13. ASSUMPTIONS (with sample text)
   - 14. GLOSSARY (with Term/Abbreviation, with sample text)
   - 15. REFERENCES (with sample text)
   - 16. APPENDIX (with sample text)
   - DISCLAIMER

   Target structure required by user:
   ```
   # Business Requirements Document

   ## 1. Project Title
   ## 2. Executive Summary
   ## 3. Business Background / Problem Statement
   ## 4. Business Objectives
   ## 5. Scope
       ### In Scope
       ### Out of Scope
   ## 6. Stakeholders
   ## 7. Functional Requirements
       (Label each as FR-01, FR-02, etc.)
   ## 8. Non-Functional Requirements
       (Label each as NFR-01, NFR-02, etc.)
   ## 9. Business Rules
   ## 10. Assumptions
   ## 11. Constraints
   ## 12. Dependencies
   ## 13. Risks
   ## 14. Success Criteria
   ```

   Important: The target structure is different from the source's table of contents. The target has 14 sections, some different names. For example, target has "Business Background / Problem Statement" and "Business Objectives", while source has "Project Description", "Business Drivers", "Current Process", "Proposed Process". Target has "Stakeholders", source doesn't explicitly have a stakeholders section (though it might be implied). Target has "Functional Requirements" labeled FR-01, etc. Target has "Non-Functional Requirements" labeled NFR-01, etc. Target has "Business Rules", "Constraints", "Dependencies", "Risks", "Success Criteria" which are not explicitly in the source's ToC (though some content might overlap).

   Rules: "Extract information ONLY from the provided source text." and "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"

   So I need to map what the source has to what the target asks for. If the source doesn't have a section or relevant info, I write that phrase.

   Let's go section by section for the target structure:

   ### Target 1: Project Title
   Source has "PROJECT NAME" line but no value. No actual project title. → "Not specified in the provided requirements."

   ### Target 2: Executive Summary
   Source has "1. EXECUTIVE SUMMARY SNAPSHOT" with sample text about EV charging. But is that "information present in the source"? The source text includes it. However, the rule says "Extract information ONLY from the provided source text." I could extract the sample text, but it's clearly a sample/template placeholder. The instruction "Do NOT invent, assume, or hallucinate any business requirements" suggests I should not treat sample text as real requirements. But the user wants me to generate a BRD from the source text. I think the intent is: the source text is the only data I have, but if it's just a template with samples, and the target structure asks for specific things, I should check if the source provides content for those exact sections. The source's Executive Summary section has content, but it's generic. I'll need to decide. To be safe and follow the rule strictly: if the source has text that could serve as executive summary, I could use it, but it might not match the target's intent. However, the rule "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'" implies that if it is present, I should use it. But the source's content is marked "SAMPLE TEXT:" which might mean it's not "actual" information but template guidance. This is ambiguous.

   Let's re-read the user's prompt carefully: "Source Document: SAMPLE BUSINESS REQUIREMENTS DOCUMENT TEMPLATE [entire template]... Rules: - Extract information ONLY from the provided source text. - Do NOT invent, assume, or hallucinate any business requirements. - If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.' - Use professional business language. - Avoid repetition across sections. - Output ONLY the final BRD in markdown. Do NOT include any thinking, reasoning, or internal notes before or after. - Begin your response with exactly: # Business Requirements Document"

   "Generate the BRD using this exact structure:" then lists the 14 sections.

   I think the key is: the source text is a template. It contains sample texts that describe what goes in each section, but there's no actual project-specific BRD content. The user wants me to output a BRD structure, and for each section, either put the content from the source if it's directly relevant, or if not present, put the "Not specified" phrase. But given that the source is entirely a template with "SAMPLE TEXT:" markers, I suspect most sections will end up as "Not specified in the provided requirements." because the sample texts are not "requirements" per se, they are descriptions of what could go in those sections. However, the rule says "Extract information ONLY from the provided source text." This might mean I should extract the sample texts as if they were the content. But that would mean hallucinating a project about EV charging stations, which seems against the spirit of "Do NOT invent, assume, or hallucinate any business requirements." The sample texts are invented examples.

   I think the safest interpretation is: The source text provides a template with sample entries, but there is no actual business requirements document content for a specific project. Therefore, for each of the target sections, since the information is not present in the source as actual project requirements (it's all template/sample), I should write "Not specified in the provided requirements." for each section. But wait, the source does have structured sections with text. Maybe I should extract the sample texts and format them into the target structure? But the target structure is different. For example, target section 3 is "Business Background / Problem Statement", source section 2 is "PROJECT DESCRIPTION" and section 5 is "CURRENT PROCESS". They have overlapping but not identical content. The rule says "If information for a section is not present in the source, write exactly: 'Not specified in the provided