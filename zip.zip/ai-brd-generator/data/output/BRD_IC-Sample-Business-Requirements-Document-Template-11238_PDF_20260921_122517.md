# Business Requirements Document ... ## 1. Project Title ... etc."
   Also: "Preserve all requirement IDs (FR-001, NFR-001, etc.) exactly as given."
   But the input doesn't actually contain any FR-001 etc. It just says "Not specified in the provided requirements." for everything.
   Wait, maybe the requirement IDs are implied in the structure? The structure has sections 1-14. But no specific IDs are in the input.
   The instruction says: "Preserve all requirement IDs (FR-001, NFR-001, etc.) exactly as given." Since none are given, I should just output the placeholders or leave them as is? Actually, I think the user wants me to follow the structure, and if there are requirement IDs, preserve them. But there are none. I'll just output the sections with "Not specified in the provided requirements." as the content.

   Let me re-read carefully: "Use ONLY the information provided. Do NOT invent or hallucinate requirements." and "If a section has no information provided, write: Not specified in the provided requirements."

   So for each section, I'll write exactly: "Not specified in the provided requirements."

   But the structure has headings like "## 1. Project Title", etc. I need to output the full BRD markdown with those headings, and under each, the text "Not specified in the provided requirements."

   However, the rule says: "Output ONLY the markdown BRD. No thinking. No reasoning. No preamble." and "Your very first character must be: #"

   So the output should start with `# Business Requirements Document` then the sections.

   Let me map the structure:
   # Business Requirements Document
   
   ## 1. Project Title
   
   ## 2. Executive Summary
   
   ... up to 14.

   For each, I'll put the content as "Not specified in the provided requirements."

   But wait: The input has sections like "### Business Problem" etc., but the structure I need to output is the one listed: "Use this exact structure: # Business Requirements Document ... ## 1. Project Title ... etc."

   I'll follow that exact structure.

   Let me draft it:

   # Business Requirements Document

   ## 1. Project Title
   Not specified in the provided requirements.

   ## 2. Executive Summary
   Not specified in the provided requirements.

   ## 3. Business Background / Problem Statement
   Not specified in the provided requirements.

   ## 4. Business Objectives
   Not specified in the provided requirements.

   ## 5. Scope

   ### In Scope
   Not specified in the provided requirements.

   ### Out of Scope
   Not specified in the provided requirements.

   ## 6. Stakeholders
   Not specified in the provided requirements.

   ## 7. Functional Requirements
   Not specified in the provided requirements.

   ## 8. Non-Functional Requirements
   Not specified in the provided requirements.

   ## 9. Business Rules
   Not specified in the provided requirements.

   ## 10. Assumptions
   Not specified in the provided requirements.

   ## 11. Constraints
   Not specified in the provided requirements.

   ## 12. Dependencies
   Not specified in the provided requirements.

   ## 13. Risks
   Not specified in the provided requirements.

   ## 14. Success Criteria
   Not specified in the provided requirements.

   Check rules:
   - Output ONLY the markdown BRD. ✅
   - No thinking. No reasoning. No preamble. ✅
   - First character must be #. ✅
   - Use ONLY the information provided. ✅ (all sections have the placeholder)
   - If a section has no information provided, write: "Not specified in the provided requirements." ✅
   - Use professional business language. ✅ (the phrase is professional enough, or I could tweak but it's specified exactly)
   - Remove the [source: chunk N] annotations from the final output. ✅ (none present)
   - Preserve all requirement IDs (FR-001, NFR-001, etc.) exactly as given. ✅ (none given, so no issue)

   Wait, the instruction says "Preserve all requirement IDs (FR-001, NFR-001, etc.) exactly as given." But there are no requirement IDs in the input. The input has "### Functional Requirements" etc., but no FR-001. Maybe the user expects me to include requirement IDs as placeholders? Or maybe the input actually has them but I'm not seeing them? Let me re-read the user message carefully.

   The user message:
   "Aggregated Requirements Information:

   ### Business Problem
   Not specified in the provided requirements.

   ### Business Objectives
   Not specified in the provided requirements.

   ...

   ### Success Criteria
   Not specified in the provided requirements."

   Then: "Use this exact structure: ..."

   And: "Preserve all requirement IDs (FR-001, NFR-001, etc.) exactly as given."

   I think the "etc." implies there might be some, but since they're not in the provided text, I should just not invent them. The rule says "Preserve all requirement IDs ... exactly as given." If none are given, I don't need to add any. I'll just output the sections as specified.

   One thing: The structure has "## 5. Scope" with "### In Scope" and "### Out of Scope". I'll follow that.

   Also, the first character must be `#`. So the output starts with `# Business Requirements Document`.

   I'll make sure there's no leading spaces before `#`.

   Final check of the output format:

   # Business Requirements Document
   
   ## 1. Project Title
   Not specified in the provided requirements.
   
   ## 2. Executive Summary
   Not specified in the provided