# Business Requirements Document
     ## 1. Project Title
     ## 2. Executive Summary
     ... etc.

   - The source text has "PROJECT NAME" and "COMPANY NAME" as placeholders. It has sample content in many sections.

   - I need to decide: Should I output the sample text as the content for each section? That would violate "Do NOT invent or hallucinate requirements" because the sample text is not real requirements, it's template instructions. But it IS in the source text. However, the sample text often says things like "SAMPLE TEXT: As a socially and environmentally conscious company..." which is clearly not a requirement but an example.

   - The rule "If a section has no information in the source, write: Not specified in the provided requirements." implies that if a section has sample text or placeholders, that might count as "no information" for a real BRD, or it might count as information. Given the strictness, I think the safest is to treat the source text as providing no actual project-specific BRD content, because it's a template. The "information" is meta-instructions about what to write, not actual requirements.

   - But wait: The user says "Generate a Business Requirements Document (BRD) from the source text below." and "Extract information ONLY from the source text." If I output "Not specified" for everything, that would be extracting that there's no information, which is technically extracting from the source (that the source lacks real info). But the source does have text.

   - Let's re-read the source. It's a "SAMPLE BUSINESS REQUIREMENTS DOCUMENT TEMPLATE". The entire thing is a template with sample text. The sample text is meant to show the user what to write. It's not actual project data. If I were to extract "information", I'd be extracting template instructions, which would result in a BRD that's just copy-pasted sample text, which would likely violate "Do NOT invent or hallucinate requirements" because I'd be presenting sample text as requirements.

   - I think the correct interpretation per the rules is: The source text does not contain a real BRD's content. It's a template. Therefore, for each section, since there's no actual project-specific information (the text is all "SAMPLE TEXT" placeholders or instructional text), I should write "Not specified in the provided requirements." But the sections do have text. However, that text is not "requirements" in the BRD sense; it's template descriptions.

   - Let's look at the exact wording: "If a section has no information in the source, write: Not specified in the provided requirements." The source has information in every section, but it's sample/template info. I need to decide if that counts as "information". Given the strict rule against hallucinating, and the fact that the source is a template, I think the intent is that if the source doesn't give actual project requirements, I should mark them as not specified. But the user might expect me to use the sample text as the content.

   - Let's think differently: Maybe the user wants me to take the template structure and fill it with the sample text provided, treating the sample text as the actual content. But the sample text is clearly marked as samples/instructions. For example, section 1 has "SAMPLE TEXT: As a socially and environmentally conscious company..." If I put that as the Executive Summary, it would be using source text, but it's not a BRD for a real project.

   - I'll re-read the user's message: "Source Document: [the template]" "STRICT RULES: Output ONLY the markdown BRD. No thinking. No reasoning. No notes. No preamble. Extract information ONLY from the source text. Do NOT invent or hallucinate requirements. If a section has no information in the source, write: Not specified in the provided requirements. Use this exact structure:"

   - I think the key is: The source text is a template with sample text. The sample text is part of the source, but it's not "requirements" per se. However, the rule says "Extract information ONLY from the source text." If I ignore the sample text and output "Not specified" for everything, I'm extracting that there's no project-specific info. But the source does have text. I need to decide per section whether the content is actual BRD info or template fluff.

   - Let's examine each section's content in the source:
     - VERSION HISTORY: Fields like VERSION, APPROVED BY, etc., are empty/placeholder. No info.
     - PROJECT NAME: "SAMPLE BUSINESS" maybe? Actually it says "PROJECT NAME" then line break, then "SAMPLE BUSINESS REQUIREMENTS DOCUMENT TEMPLATE" then "COMPANY NAME" then "Street Address..." then "webaddress.com". These are placeholders. No real info.
     - TABLE OF CONTENTS: Lists sections, but no detail.
     - 1. EXECUTIVE SUMMARY SNAPSHOT: Has "SAMPLE TEXT:" block with paragraphs about EV charging. This is sample content.
     - 2. PROJECT DESCRIPTION: "SAMPLE TEXT:" block.
     - 3. PROJECT SCOPE: "IN SCOPE" and "OUT OF SCOPE" with "SAMPLE TEXT" bullet points.
     - 4. BUSINESS DRIVERS: "SAMPLE TEXT:" block.
     - 5. CURRENT PROCESS: "SAMPLE TEXT:" block.
     - 6. PROPOSED PROCESS: "SAMPLE TEXT:" block.
     - 7. FUNCTIONAL REQUIREMENTS: Has priority table, and "SAMPLE TEXT:" requirements like "Increase the production of EV charging units."
     - 8. NON-FUNCTIONAL REQUIREMENTS: "SAMPLE TEXT:" blocks.
     - 9. FINANCIAL STATEMENTS: "SAMPLE TEXT:" block.
     - 10. COST AND BENEFIT: "SAMPLE TEXT:" block.
     - 11. RESOURCES: "SAMPLE TEXT:" block.
     - 12. SCHEDULE, TIMELINE, AND DEADLINES: "SAMPLE TEXT:" block.
     - 13. ASSUMPTIONS: "SAMPLE TEXT:" block.
     - 14. GLOSSARY: "SAMPLE TEXT is below ..." with sample terms.
     - 15. REFERENCES: "SAMPLE TEXT is below..." with sample entries.
     - 16. APPENDIX: "SAMPLE TEXT:" block.
     - DISCLAIMER: fixed text.

   - Given the rule "If a section has no information in the source, write: Not specified in the provided requirements." I need to determine if the "SAMPLE TEXT" blocks count as information. They are text, but they are explicitly samples/instructions. The rule likely intends that if a section doesn't contain actual project requirements (i.e., the source just has generic template prompts), then it's "not specified". Moreover, the rule "Do NOT invent or hallucinate requirements" strongly suggests I should not use the sample text as requirements, because that would be hallucinating project-specific needs (even though they're in the source, they're not real requirements for a specific project).

   - I think the correct approach is: For each section, check if there is actual, concrete project requirement information. The source is a template; it doesn't have a specific project's BRD. Therefore, all sections lack actual project requirements. I should output "Not specified in the provided requirements." for each section that doesn't have real data. But the structure requires me to fill the sections. The user says "Use this exact structure:" and lists sections. I need to output the markdown with those section headers, and under each, either content extracted from source or "Not specified...".

   - Let's read the rule again: "If a section has no information in the source, write: Not specified in the provided requirements." This implies that if a section DOES have information, I should extract it. But the source's information is all sample/template. I'm in a dilemma.

   - Perhaps the user expects me to treat the "SAMPLE TEXT" as the actual content to put in the BRD, since it's in the source. But that would be weird because the sample text includes things like "Etc." and instructional language. Also, the rule "Do NOT invent or hallucinate requirements" would be violated if I present sample instructional text as BR