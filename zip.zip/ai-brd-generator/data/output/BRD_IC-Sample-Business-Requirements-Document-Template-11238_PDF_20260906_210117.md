Here's a thinking process:

1.  **Analyze User Input:**
   - User provides a "Source Document" which is actually a sample BRD template with sample text.
   - The task is to "generate a professional, structured Business Requirements Document (BRD) from the provided source text."
   - Rules: Extract information ONLY from the provided source text. Do NOT invent, assume, or hallucinate. If info is missing, write exactly: "Not specified in the provided requirements." Use professional business language. Avoid repetition. Use the exact markdown structure provided.

2.  **Analyze the Source Text:**
   - The source text is a template with sample text. It has sections like VERSION HISTORY, TABLE OF CONTENTS, and then sample content for each section.
   - It's clearly a template, not a real project's BRD. The content is all "SAMPLE TEXT" placeholders.
   - There's no actual project-specific information. Everything is marked as "SAMPLE TEXT" or generic placeholders.
   - The user wants me to generate a BRD *from the provided source text*, but the source text doesn't contain real requirements - it's a template showing what a BRD *could* look like.

3.  **Identify the Core Problem:**
   - The source text is a template with sample text. It doesn't have actual business requirements.
   - The rules say: "Extract information ONLY from the provided source text." and "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"
   - Since the source is entirely sample/template text, almost all sections will have "Not specified in the provided requirements." unless I can extract something that's actually in there.
   - Let me scan carefully for any non-sample, actual content:
     - VERSION HISTORY: Has placeholders like VERSION, APPROVED BY, REVISION, DATE, DESCRIPTION OF CHANGE, AUTHOR. No actual values.
     - TABLE OF CONTENTS: Just section numbers and titles, some with page numbers as placeholders.
     - 1. EXECUTIVE SUMMARY SNAPSHOT: Has "SAMPLE TEXT:" with placeholder content.
     - 2. PROJECT DESCRIPTION: "SAMPLE TEXT:" placeholders.
     - 3. PROJECT SCOPE: "SAMPLE TEXT:" placeholders for In Scope and Out of Scope.
     - 4. BUSINESS DRIVERS: "SAMPLE TEXT:" placeholders.
     - 5. CURRENT PROCESS: "SAMPLE TEXT:" placeholders.
     - 6. PROPOSED PROCESS: "SAMPLE TEXT:" placeholders.
     - 7. FUNCTIONAL REQUIREMENTS: Has priority table and "SAMPLE TEXT:" placeholders for requirements.
     - 8. NON-FUNCTIONAL REQUIREMENTS: "SAMPLE TEXT:" placeholders.
     - 9. FINANCIAL STATEMENTS: "SAMPLE TEXT:" placeholders.
     - 10. COST AND BENEFIT: "SAMPLE TEXT:" placeholders.
     - 11. RESOURCES: "SAMPLE TEXT:" placeholders.
     - 12. SCHEDULE, TIMELINE, AND DEADLINES: "SAMPLE TEXT:" placeholders.
     - 13. ASSUMPTIONS: "SAMPLE TEXT:" placeholders.
     - 14. GLOSSARY: "SAMPLE TEXT is below ..." with sample entries.
     - 15. REFERENCES: "SAMPLE TEXT is below..." with sample entries.
     - 16. APPENDIX: Placeholder text.
     - DISCLAIMER: Standard text, but not project requirements.

   - Essentially, the entire source is sample/template text. There are no actual business requirements extracted from a real project. The "SAMPLE TEXT" markers indicate it's a template.

4.  **Determine the Approach:**
   - I need to generate a BRD structure as requested.
   - For each section, I must check if there's actual information in the source text that I can extract.
   - Since the source is a template with "SAMPLE TEXT" placeholders, I should treat the sample text as not being "actual project requirements" because they're clearly marked as samples/placeholders.
   - The rules say: "Extract information ONLY from the provided source text." and "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"
   - The sample text IS in the source text, but it's explicitly labeled "SAMPLE TEXT" and is clearly placeholder content. However, the rule says extract info ONLY from the source text. I need to decide: do I treat the sample text as valid content to extract, or do I treat the absence of actual project-specific info as "not specified"?
   - Re-reading the rules: "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'" The sample text is present in the source, but it's generic template text. The intent of the task is likely to test if I can distinguish between actual project requirements and template placeholders. Given the strict rule "Do NOT invent, assume, or hallucinate any business requirements," and the fact that the source is a template, I should probably treat the sample text as "not actual requirements" or perhaps extract the section titles/markers but not the sample content as real requirements.
   - Actually, the user says: "Generate the BRD using this exact structure:" and provides the markdown structure. The source text is the "provided source text." I need to go through each section and either extract what's there or put "Not specified in the provided requirements."
   - Let's look at the source text carefully. It has sections like "1. EXECUTIVE SUMMARY SNAPSHOT" with "SAMPLE TEXT:" followed by placeholder content. The sample text includes bullet points like "As a socially and environmentally conscious company..." etc.
   - If I extract that, I'd be hallucinating project specifics because it's just a sample template. The responsible thing is to recognize that the source is a template and contains no actual project requirements.
   - I'll treat the entire source as "not specifying actual business requirements" because everything is either a placeholder or sample text. I'll put "Not specified in the provided requirements." for each section, as the rules dictate when information isn't present. But wait, the sample text IS present. I need to be precise.
   - Let me re-read the rules: "Extract information ONLY from the provided source text. Do NOT invent, assume, or hallucinate any business requirements. If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"
   - The key is: is the sample text "information present in the source"? Yes, but it's clearly marked as sample/template. If I extract it, I'd be using template text as actual requirements, which violates "Do NOT invent, assume, or hallucinate any business requirements." The sample text is not from a real project; it's a template. So I should not extract it as real requirements.
   - I think the intended approach is: since the source text is a generic template with no actual project data, each section will have "Not specified in the provided requirements." This aligns with the rule about sections not having information present (because the "information" is just sample text, not actual requirements).
   - I'll generate the BRD structure, and for each section, I'll write "Not specified in the provided requirements." because the source contains only template/sample text, no actual business requirements for a specific project.
   - Wait, let me double-check if any section has non-sample content. The VERSION HISTORY has placeholders but no values. The DISCLAIMER at the end is generic. The TABLE OF CONTENTS just lists sections. Nothing is actual project requirements.
   - I'll proceed by putting "Not specified in the provided requirements." for all sections 1-14 (and 15, 16 if applicable, but the structure goes to 14 in the markdown structure provided? Wait, the user's requested structure goes to 14: "Success Criteria". The template has 16 sections, but the user specified: "Use the exact markdown structure provided." The structure they provided goes from 1 to 14, with sections: 1. Project Title, 2. Executive Summary, 3. Business Background / Problem Statement, 4. Business Objectives, 5. Scope (In Scope / Out of Scope), 6. Stakeholders, 7. Functional Requirements, 8. Non-Functional Requirements, 9. Business Rules, 10. Assumptions, 11. Constraints, 12. Dependencies, 13. Risks, 14. Success Criteria.
   - The template has more sections (up to 16), but the user wants the exact structure they provided, which stops at 14. I need to follow that exact structure.
   - So I'll generate sections 1 through 14 as per the user's structure.
   - For each, I'll check if the source text has actual info. It doesn't. So each will have "Not specified in the provided requirements."
   - But wait: section 5 in the user's structure is "Scope" with "In Scope" and "Out of Scope". The template has section 3 as "PROJECT SCOPE" with In Scope and Out of Scope samples. But the user's structure maps it differently. I need to map the user's structure sections to what might be in the source, but the rule says extract ONLY from source, and if not present, put the exact phrase.
   - Let's map user's 14 sections to possible source content, but since source is all sample, I'll just put the phrase for each.
   - Actually, I should try to extract whatever is minimally there. For example, section 1: "Project Title". The source has "PROJECT NAME" and "COMPANY NAME" placeholders but no values. So "Not specified".
   - Section 2: "Executive Summary". Source has "1. EXECUTIVE SUMMARY SNAPSHOT" with sample text. But it's sample text. I'll put "Not specified".
   - I'll be consistent: all sections get "Not specified in the provided requirements." because the source is a template with no actual project requirements.
   - Let me re-read the user's prompt carefully: "Source Document: [the template] ... Generate the BRD using this exact structure: [structure] ... Rules: Extract information ONLY from the provided source text. Do NOT invent, assume, or hallucinate any business requirements. If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'"
   - The source text is the entire block including the template. It's possible the user wants me to use the sample text as content, but that would violate "Do NOT invent, assume, or hallucinate." The sample text is clearly marked as sample, not real requirements. I think the correct interpretation is that since the source doesn't contain actual business requirements for a specific project, I should output the BRD structure with "Not specified" for each section.
   - However, sometimes in these prompts, the "source text" includes the sample text that the user wants me to use as-is. But the rules explicitly say not to hallucinate, and the sample text is generic. I'll err on the side of the rules.
   - Let me check if any section in the user's structure has a direct, non-sample counterpart in the source that I could extract verbatim without hallucinating. 
     - User section 1: Project Title. Source has "PROJECT NAME" line but no value. -> Not specified.
     - User section 2: Executive Summary. Source has sample text under "1. EXECUTIVE SUMMARY SNAPSHOT". It's sample, but it's text. If I extract it, I'd be putting sample text as the BRD content. The rule says "Extract information ONLY from the provided source text." The sample text IS in the source. But it also says "Do NOT invent, assume, or hallucinate any business requirements." Using sample template text as actual requirements could be seen as hallucinating project specifics. I think the intent is that the source is a template, and I should recognize it's not a real BRD, so I output "Not specified".
     - I'll proceed with "Not specified in the provided requirements." for all sections. It's safe and compliant.
   - Wait, maybe the user expects me to use the sample text as the content, since it's "provided source text". Let me read the very first line: "You are a senior business analyst. Your task is to generate a professional, structured Business Requirements Document (BRD) from the provided source text." and "Rules: Extract information ONLY from the provided source text." If the source text has sample content, maybe I should extract it. But the sample content is clearly placeholders ("SAMPLE TEXT: As a socially and environmentally conscious company..."). If I extract that, I'm using text that's marked as sample, which might be against the spirit of "do not hallucinate." However, the rule says "If information for a section is not present in the source, write exactly: 'Not specified in the provided requirements.'" The sample text is present, so maybe I should use it? But it says "Do NOT invent, assume, or hallucinate any business requirements." The sample text is not "hallucinated"; it's extracted. But it's generic and not specific to a project.
   - I need to make a decision. I'll look at the structure the user wants. It's a standard BRD outline. The source is a template. I think the most reasonable interpretation, given the strict rules, is that the source contains no actual project requirements, so each section gets "Not specified." This avoids hallucinating and follows the rule about sections not having information present (the "information" is just template noise).
   - Actually,